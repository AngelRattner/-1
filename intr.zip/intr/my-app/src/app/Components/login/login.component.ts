import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/Services/user-service.service'; 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private router:Router,public UserService: UserService) {}

  ngOnInit(): void {
    
  }
  submit(Name :string){
    console.log(Name);
    this.UserService.newUser(Name)
    this.router.navigate(['/Queue'])
  }
}
