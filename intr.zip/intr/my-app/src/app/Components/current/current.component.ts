import { Component, OnInit } from '@angular/core';
import { SignalRService } from 'src/app/Services/signal-r.service';
var LastUser;
@Component({
  selector: 'app-current',
  templateUrl: './current.component.html',
  styleUrls: ['./current.component.css']
})
export class CurrentComponent implements OnInit {

  constructor(public signalR : SignalRService) { }

  ngOnInit(): void {

    setTimeout(() => {
      this.signalR.getLastUser();
    }, 2000);
  }
  Next(){
        this.signalR.nextUser()
  }
}
