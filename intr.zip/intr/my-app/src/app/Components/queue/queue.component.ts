import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Models/user/user'; 
import { SignalRService } from 'src/app/Services/signal-r.service';

var CurrentUser;
var ListOfUsers
@Component({
  selector: 'app-queue',
  templateUrl: './queue.component.html',
  styleUrls: ['./queue.component.css']
})
export class QueueComponent implements OnInit {
  Users :User[]=[];
  constructor(public SignalR:SignalRService) { }

  ngOnInit(): void {
    setTimeout(() => {
      this.SignalR.getUsers();
    }, 2000);
  }

}
