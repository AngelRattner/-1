export class User {
  constructor(
       public Name:string,
       public EnterTime:Date,
    ) {}
}
