import { Injectable } from '@angular/core';
import * as signalR from '@aspnet/SignalR';

@Injectable({providedIn: 'root'})
export class SignalRService {
  constructor() { }
  ListOfUsers: [] = []; 
  LastUser: any
  hubConnection!: signalR.HubConnection; 
  

  startConnection = () => {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl('http://localhost:5000/Socket', {
        skipNegotiation: true,
        transport: signalR.HttpTransportType.WebSockets
      })
      .build();

    this.hubConnection

      .start()
      .then(() => {
        console.log('Hub Connection Started!');
      })
      .catch(err => console.log('Error while starting connection: ' + err))
  }
  newUser(user: any){
    this.hubConnection.invoke('newUser',user)
  }
  nextUser(){
    this.hubConnection.invoke("NextUser")
  }
  getUsers(){
    this.hubConnection.on('GetUserResponse',(Users)=>{
      this.ListOfUsers=Users;
      console.log(Users);
    });
  }
  getLastUser(){
    this.hubConnection.on('LastUserResponse',(Users)=>{
      this.LastUser=Users;
      console.log(Users);
    });
  }

}
