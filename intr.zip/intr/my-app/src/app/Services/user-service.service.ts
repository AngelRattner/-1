import { Injectable } from '@angular/core';
import { User } from '../Models/user/user';
import { SignalRService } from './signal-r.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(public signalR : SignalRService) {this.signalR.startConnection()}
  CurrentUser :User | undefined

  newUser(name : string){
    this.signalR.newUser(name)
  }

  getUsers(){
    this.signalR.getUsers();
  }

  nextUser(){
    this.signalR.nextUser()
  }
  
}
