import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CurrentComponent } from './Components/current/current.component';
import { LoginComponent } from './Components/login/login.component';
import { QueueComponent } from './Components/queue/queue.component';

const routes: Routes = [
  {path:"", redirectTo: 'Login',pathMatch:'full'},
  {path:'Login', component:LoginComponent},
  {path:'Queue',component:QueueComponent},
  {path:'Current',component:CurrentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
