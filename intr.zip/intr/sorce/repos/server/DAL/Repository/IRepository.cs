﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.Repository
{
    public interface IRepository
    {
        void NewUser(User user);
        void RemoveUser(User user);
        List<User> GetUsers();
    }
}
