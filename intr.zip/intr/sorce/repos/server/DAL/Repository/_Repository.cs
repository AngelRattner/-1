﻿using DAL.Context;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL.Repository
{
    public class _Repository : IRepository
    {
        private UserContext UserContext;
        public _Repository(UserContext UserContext)
        {
            this.UserContext = UserContext;
        }
        public List<User> GetUsers()
        {
            return UserContext.users.ToList();
        }

        public void NewUser(User user)
        {
            UserContext.Add(user);
            UserContext.SaveChanges();
        }

        public void RemoveUser(User user)
        {
            UserContext.Remove(user);
            UserContext.SaveChanges();
        }
    }
}
