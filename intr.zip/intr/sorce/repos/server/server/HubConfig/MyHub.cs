﻿using BL;
using DAL.Repository;
using Entity;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.HubConfig
{
    public class MyHub :Hub, IHub
    {
        protected IHubContext<MyHub> context;
        private readonly IRepository repository;
        private IQueueManger queueManger;
        public MyHub(IHubContext<MyHub> context, IRepository repository, IQueueManger queueManger)
        {
            this.repository = repository;
            this.context = context;
            this.queueManger = queueManger;
        }
        public async Task getUsers(List<User> users)
        {

            await context.Clients.All.SendAsync("GetUserResponse", users);
        }

        public async Task newUser(string name)
        {
            queueManger.newUser(name);
           await getUsers(queueManger.GetUsers());
        }

        public async Task NextUser()
        {
            queueManger.NextUser();
            await getUsers(queueManger.GetUsers());
        }

        public async Task LastUser()
        {
            await context.Clients.All.SendAsync("LastUserResponse", queueManger.GetLastUser());
        }
    }
}
