﻿using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.HubConfig
{
    public interface IHub
    {
        public Task newUser(string name);
        public Task getUsers(List<User> users);
        public Task NextUser();
        public Task LastUser();
    }
}
