using BL;
using DAL.Context;
using DAL.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using server.HubConfig;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace server
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IHub, MyHub>();
            services.AddTransient<IRepository, _Repository>();
            services.AddTransient<IQueueManger, QueueManger>();
            string connectionString = Configuration.GetConnectionString("DefaultConnection");
            services.AddDbContext<UserContext>(option => option.UseLazyLoadingProxies().UseSqlServer(connectionString));
            services.AddControllersWithViews();
            services.AddCors(option =>
            {
                option.AddPolicy("AllowAllHeaders", builder =>
                {
                    builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
                });
            });
            services.AddSignalR(option =>
            {
                option.EnableDetailedErrors = true;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env,UserContext userContext)
        {
            userContext.Database.EnsureDeleted();
            userContext.Database.EnsureCreated();
            app.UseRouting();
            app.UseCors("AllowAllHeaders");
    
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute("Default", "{Controller=Home}/{action=Index}/{id?}");
                endpoints.MapHub<MyHub>("/Socket");
            });
        }
    }
}
