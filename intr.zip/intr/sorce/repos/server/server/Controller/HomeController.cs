﻿using BL;
using DAL.Repository;
using Entity;
using Microsoft.AspNetCore.Mvc;
using server.HubConfig;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Controller
{
    public class HomeController : ControllerBase
    {
        private IRepository repository;
        private IHub hub;
        private IQueueManger queueManger;
        public HomeController(IRepository repository, IHub hub, IQueueManger queueManger)
        {
            this.repository = repository;
            this.hub = hub;
            this.queueManger = queueManger;
        }
        public void NewUser([FromBody] string name)
        {
            queueManger.newUser(name);
            hub.getUsers(queueManger.GetUsers());
        }
        public void NextUser()
        {
            queueManger.NextUser();
            hub.getUsers(queueManger.GetUsers());
        }
    }
}
