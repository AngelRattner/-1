﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace BL
{
    public interface IQueueManger
    {
        void newUser(string name);
        void NextUser();
        List<User> GetUsers();
        User GetLastUser();

    }
}
