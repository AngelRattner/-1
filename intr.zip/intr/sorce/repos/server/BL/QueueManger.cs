﻿using DAL.Repository;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BL
{
    public class QueueManger : IQueueManger
    {
        private IRepository rpository;
        Queue<User> Users = new Queue<User>();
        public QueueManger(IRepository rpository)
        {
            this.rpository = rpository;
        }

        public User GetLastUser()
        {
           return Users.Peek();
        }

        public List<User> GetUsers()
        {
            return Users.ToList();
        }

        public void newUser(string name)
        {
            User user = new User() { Name = name, EnterTime = DateTime.Now };
            Users.Enqueue(user);
            rpository.NewUser(user);
        }

        public void NextUser()
        {
            rpository.RemoveUser(Users.Dequeue());
        }
    }
}
